<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <meta name="description" content="<?php echo $description; ?>">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
</head>
<body>
    <header class="header">
        <div class="container">
            <nav class="nav">
                <a class="logo" href="<?= rtrim(BASE_URL, '/') ?>/"><img src="<?= rtrim(BASE_URL, '/') ?>/uploads/img/apoena-logo.jpg" alt="GRUPO APOENA" class="logo-img"></a>
                <ul class="nav-links">
                    <li><a class="active" href="<?= rtrim(BASE_URL, '/') ?>/">Home</a></li>
                    <li><a href="<?= rtrim(BASE_URL, '/') ?>/about/">Sobre</a></li>
                    <li><a href="<?= rtrim(BASE_URL, '/') ?>/biotech/">Biotech</a></li>
                    <li><a href="<?= rtrim(BASE_URL, '/') ?>/bioprospeccao/">Bioprospecção</a></li>
                    <li><a href="<?= rtrim(BASE_URL, '/') ?>/sustentabilidade/">Sustentabilidade</a></li>
                    <li><a href="<?= rtrim(BASE_URL, '/') ?>/blog/">Soluções</a></li>
                    <li><a href="<?= rtrim(BASE_URL, '/') ?>/contato/">Contato</a></li>
                    <li>|</li>
                    <li class="nav-login-item">
                        <a href="<?= rtrim(BASE_URL, '/') ?>/admin/login" class="nav-login-btn">
                            Login
                        </a>
                    </li>
                </ul>
            </nav>

        </div>
    </header>

    <main>
        <section class="hero" style=" background-image: linear-gradient(rgba(0,0,0,0.45), rgba(0,0,0,0.45)), url('<?= rtrim(BASE_URL, '/') ?>/uploads/img/bg-hero.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat;">
            <div class="container">
                <h1 style="color:#fff;">
                    Transformando o Futuro com <span class="highlight" style="color:#fff;">Biotecnologia</span>
                </h1>
            
                <p style="color:#fff;">
                    O Grupo Apoena é o hub de inovação estratégica para biociência,
                    agronegócio e cuidados pessoais.
                </p>
            
                <div class="cta-group">
                    <a href="#solucoes" class="btn btn-primary">Conheça nossas Unidades</a>
                </div>
            </div>
        </section>
        
        <section class="about" style="padding:80px 0; background:#fff;">
            <div class="container" style="
                display:flex;
                align-items:center;
                gap:60px;
                flex-wrap:wrap;
            ">
                <!-- IMAGEM -->
                <div style="flex:1; min-width:300px;">
                    <img 
                        src="<?= rtrim(BASE_URL, '/') ?>/uploads/img/sobre-nos.jpg" 
                        alt="Processo biotecnológico Apoena"
                        style="
                            width:100%;
                            height:auto;
                            border-radius:12px;
                            display:block;
                        "
                    >
                </div>
        
                <!-- CONTEÚDO -->
                <div style="flex:1; min-width:300px; max-width:560px;">
                    <h2 style="
                        font-size:32px;
                        margin-bottom:24px;
                        color:#0b2c4d;
                    ">
                        Sobre Nós
                    </h2>
        
                    <p style="
                        font-size:16px;
                        line-height:1.7;
                        margin-bottom:16px;
                        color:#333;
                    ">
                        A Apoena Biotech nasceu em 2018 com o propósito de impactar
                        positivamente o desenvolvimento sustentável por meio da
                        biotecnologia.
                    </p>
        
                    <p style="
                        font-size:16px;
                        line-height:1.7;
                        margin-bottom:16px;
                        color:#333;
                    ">
                        Apoiamos projetos de inovação com tecnologia em bioprocessos e
                        desenvolvimento de produtos 100% biotecnológicos para os
                        mercados agro, de beleza e cuidados pessoais.
                    </p>
        
                    <p style="
                        font-size:16px;
                        line-height:1.7;
                        margin-bottom:24px;
                        font-weight:600;
                        color:#2e7d32;
                    ">
                        Em 2021 nos tornamos a 1ª Indústria brasileira em biotech para o
                        setor de Higiene Pessoal, Perfumaria e Cosméticos.
                    </p>
        
                    <a 
                        href="<?= rtrim(BASE_URL, '/') ?>/about/"
                        style="
                            display:inline-block;
                            padding:12px 28px;
                            background:#2f80ed;
                            color:#fff;
                            text-decoration:none;
                            border-radius:6px;
                            font-weight:600;
                        "
                    >
                        Saiba mais
                    </a>
                </div>
            </div>
        </section>
        
        <section style="
            background:#f6f7f6;
            padding:80px 24px;
            font-family:Inter, Arial, sans-serif;
        ">
            <div style="
                max-width:1200px;
                margin:0 auto;
                display:flex;
                align-items:center;
                gap:56px;
                background:#fff;
                border-radius:24px;
                padding:48px;
                box-shadow:0 12px 40px rgba(0,0,0,0.08);
            ">
                
                <!-- IMAGEM -->
                <div style="flex:1;">
                    <img 
                        src="<?= rtrim(BASE_URL, '/') ?>/uploads/img/foto_pessoa.jpg"
                        alt="Biotecnologia sustentável"
                        style="
                            width:100%;
                            height:auto;
                            border-radius:20px;
                            object-fit:cover;
                        "
                    >
                </div>
        
                <!-- TEXTO -->
                <div style="flex:1.2;">
                    <h2 style="
                        color:#00a651;
                        font-size:22px;
                        line-height:1.4;
                        margin:0 0 20px 0;
                        font-weight:700;
                    ">
                        Que valores seus produtos compartilham hoje?<br>
                        E quais desejam compartilhar?
                    </h2>
        
                    <p style="
                        font-size:15px;
                        line-height:1.8;
                        color:#333;
                        margin:0 0 18px 0;
                    ">
                        Inovação, performance e o menor impacto ao meio ambiente?
                        Consumo e produção responsáveis? Contribuição para uma
                        economia regenerativa? Saúde e bem-estar?
                    </p>
        
                    <p style="
                        font-size:15px;
                        line-height:1.8;
                        color:#333;
                        margin:0 0 28px 0;
                    ">
                        Produtos biotecnológicos podem se consolidar como alternativas
                        para substituição de insumos e processos tradicionais não
                        sustentáveis, favorecendo a perenidade e rentabilidade de
                        longo prazo aos negócios.
                        <strong style="color:#00a651;">Vem com a gente e descubra como!</strong>
                    </p>
        
                    <a href="<?= BASE_URL ?>/contato/" style="
                        display:inline-block;
                        background:#00c389;
                        color:#fff;
                        text-decoration:none;
                        padding:14px 36px;
                        border-radius:999px;
                        font-size:13px;
                        font-weight:700;
                        letter-spacing:1px;
                    ">
                        ENTRAR EM CONTATO
                    </a>
                </div>
        
            </div>
        </section>

        
        <section id="solucoes" class="units" style="padding:80px 0; background:#f8f9fb;">
            <div class="container">
                <h2 style="
                    text-align:center;
                    font-size:32px;
                    margin-bottom:48px;
                    color:#0b2c4d;
                ">
                    Nossas Unidades de Negócio
                </h2>
        
                <div style="
                    display:grid;
                    grid-template-columns:repeat(auto-fit, minmax(260px, 1fr));
                    gap:32px;
                ">
                    <?php foreach ($sites as $index => $site): ?>
        
                    <?php
                        /* IMAGENS ABSOLUTAS INLINE */
                        $bgImages = [
                            '/uploads/img/biotech.jpg',
                            '/uploads/img/agro.jpg',
                            '/uploads/img/biocare.jpg'
                        ];
                        $bgImage = $bgImages[$index % count($bgImages)];
                    ?>
        
                    <div style="
                        position:relative;
                        min-height:280px;
                        border-radius:16px;
                        overflow:hidden;
                        background-image:url('<?php echo $bgImage; ?>');
                        background-size:cover;
                        background-position:center;
                        display:flex;
                        align-items:flex-end;
                    ">
                        <!-- OVERLAY -->
                        <div style="
                            position:absolute;
                            inset:0;
                            background:linear-gradient(
                                rgba(0,0,0,0.15),
                                rgba(0,0,0,0.85)
                            );
                            z-index:1;
                        "></div>
        
                        <!-- CONTEÚDO -->
                        <div style="
                            position:relative;
                            z-index:2;
                            padding:24px;
                            color:#fff;
                        ">
                            <h3 style="
                                font-size:20px;
                                margin-bottom:12px;
                                color:#fff;
                            ">
                                <?php echo $site['name']; ?>
                            </h3>
        
                            <p style="
                                font-size:15px;
                                line-height:1.6;
                                margin-bottom:16px;
                                color:#f1f1f1;
                            ">
                                <?php echo $site['description']; ?>
                            </p>
        
                            <a 
                                href="<?php echo $site['url']; ?>" 
                                target="_blank"
                                style="
                                    color:#fff;
                                    font-weight:600;
                                    text-decoration:none;
                                    border-bottom:2px solid rgba(255,255,255,0.8);
                                    padding-bottom:2px;
                                "
                            >
                                Acessar Site →
                            </a>
                        </div>
                    </div>
        
                    <?php endforeach; ?>
                </div>
            </div>
        </section>


    </main>

    <footer style="background:#00c389; color:#fff; font-family:Inter, Arial, sans-serif;">
    
    <!-- CONTEÚDO PRINCIPAL -->
    <div style="
        max-width:1200px;
        margin:0 auto;
        padding:56px 24px 40px;
        display:grid;
        grid-template-columns: 1fr 1fr;
        gap:48px;
    ">
        
        <!-- ESQUERDA: LOGO + MENU -->
        <div>
            <img 
                src="<?= rtrim(BASE_URL, '/') ?>/uploads/img/apoena-logo-branco.png"
                alt="Grupo Apoena"
                style="max-width:180px; height:auto; margin-bottom:28px;"
            >

            <nav style="
                display:flex;
                gap:20px;
                flex-wrap:wrap;
                font-size:13px;
                font-weight:600;
            ">
                <a href="<?= BASE_URL ?>/about/" style="color:#fff; text-decoration:none;">QUEM SOMOS</a>
                <a href="<?= BASE_URL ?>/biotech/" style="color:#fff; text-decoration:none;">BIOTECH</a>
                <a href="<?= BASE_URL ?>/bioprospeccao/" style="color:#fff; text-decoration:none;">BIOPROSPECÇÃO</a>
                <a href="<?= BASE_URL ?>/sustentabilidade/" style="color:#fff; text-decoration:none;">SUSTENTABILIDADE</a>
                <a href="<?= BASE_URL ?>/blog/" style="color:#fff; text-decoration:none;">BLOG</a>
                <a href="<?= BASE_URL ?>/contato/" style="color:#fff; text-decoration:none;">CONTATO</a>
            </nav>
        </div>

        <!-- DIREITA: FALE CONOSCO -->
        <div style="font-size:14px; line-height:1.8;">
            <strong style="display:block; margin-bottom:12px;">FALE CONOSCO</strong>

            +55 (11) 4091-7783<br>

            Comercial Cosméticos:<br>
            +55 (11) 99451-3891 | +55 (11) 99966-9881<br><br>

            Comercial Agro:<br>
            +55 (19) 98707-5391 | +55 (11) 99966-9881<br><br>

            <a href="mailto:contato@apoena.com.br" style="color:#fff; text-decoration:none;">
                contato@apoena.com.br
            </a>
        </div>

        <!-- ESQUERDA INFERIOR: ENDEREÇO -->
        <div style="font-size:14px; line-height:1.8;">
            Rua Solimões, 121 – Galpão 03<br>
            CEP 09930-570 | Jardim Campanário – Diadema
        </div>

        <!-- DIREITA INFERIOR: REDES + POLÍTICA -->
        <div style="text-align:right;">
            <div style="
                display:flex;
                justify-content:flex-end;
                gap:16px;
                font-size:20px;
                margin-bottom:24px;
            ">
                <a href="#" style="color:#fff;"><i class="fab fa-linkedin-in"></i></a>
                <a href="#" style="color:#fff;"><i class="fab fa-instagram"></i></a>
                <a href="#" style="color:#fff;"><i class="fab fa-whatsapp"></i></a>
                <a href="#" style="color:#fff;"><i class="fab fa-youtube"></i></a>
                <a href="#" style="color:#fff;"><i class="fab fa-tiktok"></i></a>
            </div>

            <a href="<?= BASE_URL ?>/politica-de-privacidade/" style="
                color:#fff;
                font-size:13px;
                text-decoration:none;
            ">
                Política de Privacidade
            </a>
        </div>

    </div>

    <!-- BARRA INFERIOR -->
    <div style="
        background:#8cc63f;
        text-align:center;
        padding:16px 24px;
        font-size:13px;
    ">
        © <?= date('Y') ?> – Todos os direitos reservados à Apoena Biotech
    </div>

</footer>




    <script>
        function toggleMenu() {
            // Toggle do menu (mobile)
            document.body.classList.toggle('menu-open');

            // Atualiza aria-expanded
            const toggle = document.querySelector('.nav-toggle');
            const isOpen = document.body.classList.contains('menu-open');
            toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        }

        // Fecha ao clicar em qualquer link
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', () => {
                document.body.classList.remove('menu-open');

                const toggle = document.querySelector('.nav-toggle');
                toggle.setAttribute('aria-expanded', 'false');
            });
        });

        // Fecha ao clicar fora
        document.addEventListener('click', function(e) {
            const nav = document.querySelector('.nav');
            const toggle = document.querySelector('.nav-toggle');

            if (!document.body.classList.contains('menu-open')) return;

            if (!nav.contains(e.target) && !toggle.contains(e.target)) {
                document.body.classList.remove('menu-open');
                toggle.setAttribute('aria-expanded', 'false');
            }
        });

        // Fecha com ESC (extra, mas sem mudar nada da estrutura)
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                document.body.classList.remove('menu-open');
                const toggle = document.querySelector('.nav-toggle');
                toggle.setAttribute('aria-expanded', 'false');
            }
        });
    </script>
</body>
</html>

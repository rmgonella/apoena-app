<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'u591057133_apoena');
define('DB_USER', 'u591057133_apoena');
define('DB_PASS', '^r0CvG7~');

define('BASE_URL', 'https://apoena.techinnovationbr.com.br/');
define('SITE_NAME', 'Grupo Apoena');

// Site specific domains/paths
define('DOMAINS', [
    'main' => 'https://apoena.techinnovationbr.com.br/',
    'biotech' => 'biotech.apoena.com.br',
    'agro' => 'agro.apoena.com.br',
    'biocare' => 'biocare.apoena.com.br'
]);

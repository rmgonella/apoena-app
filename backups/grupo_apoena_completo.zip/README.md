# Grupo Apoena - Ecossistema Digital

Este projeto é a reformulação completa do ecossistema digital do Grupo Apoena, desenvolvido em PHP puro (>= 8.x) seguindo uma arquitetura MVC leve e modular.

## Estrutura do Projeto

- `app/`: Contém a lógica da aplicação (Controllers, Models, Views).
- `config/`: Arquivos de configuração (Banco de dados, URLs).
- `core/`: Classes base do sistema (Database, Router).
- `public/`: Única pasta acessível publicamente (Index, CSS, JS, Imagens).
- `database/`: Schema do banco de dados MySQL.

## Tecnologias Utilizadas

- **Backend:** PHP 8.x, PDO (MySQL), Router customizado.
- **Frontend:** HTML5, CSS3 (Flexbox/Grid), JavaScript Vanilla.
- **Segurança:** Sanitização de inputs, Proteção CSRF, Controle de Sessão.
- **SEO:** URLs amigáveis, Meta tags dinâmicas, Schema markup.

## Instalação

1. Importe o arquivo `database/schema.sql` no seu servidor MySQL.
2. Configure as credenciais de banco de dados em `config/config.php`.
3. Aponte o seu servidor web (Apache/Nginx) para a pasta `public/`.
4. Certifique-se de que o módulo `mod_rewrite` do Apache esteja ativo.

## Credenciais de Acesso (Admin)

- **URL:** `your-domain.com/admin/login`
- **E-mail:** `admin@apoena.com.br`
- **Senha:** `admin123`

---
Desenvolvido por **Rodrigo Marchi Gonella**.

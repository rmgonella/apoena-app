<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre o Grupo Apoena</title>
    <meta name="description" content="Conheça a história, missão e valores do Grupo Apoena.">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <nav class="nav">
                <div class="logo">GRUPO APOENA</div>
                <ul class="nav-links">
                    <li><a href="<?php echo BASE_URL; ?>">Home</a></li>
                    <li><a href="#sobre">Sobre</a></li>
                    <li><a href="#contato">Contato</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="hero" style="padding: 60px 0;">
            <div class="container">
                <h1>Sobre o Grupo Apoena</h1>
                <p>Transformando ciência em soluções reais para o futuro.</p>
            </div>
        </section>

        <section class="content-section">
            <div class="container">
                <h2>Nossa História</h2>
                <p>O Grupo Apoena nasceu da visão de criar um ecossistema de inovação que conecta biotecnologia, agronegócio e cuidados pessoais. Com foco em pesquisa, desenvolvimento e aplicação prática de soluções científicas, consolidamos nossa posição como referência em inovação sustentável.</p>

                <div style="margin-top: 50px;">
                    <h2>Missão, Visão e Valores</h2>
                    <div class="grid">
                        <div class="card">
                            <h3>Missão</h3>
                            <p>Desenvolver soluções inovadoras em biotecnologia que transformem positivamente a vida das pessoas e o meio ambiente.</p>
                        </div>
                        <div class="card">
                            <h3>Visão</h3>
                            <p>Ser referência global em inovação científica e sustentabilidade nos segmentos de biotech, agro e personal care.</p>
                        </div>
                        <div class="card">
                            <h3>Valores</h3>
                            <p>Inovação, integridade, sustentabilidade, excelência científica e compromisso com o futuro.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer class="footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Grupo Apoena. Desenvolvido por Rodrigo Marchi Gonella.</p>
        </div>
    </footer>
</body>
</html>

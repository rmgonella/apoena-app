<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <meta name="description" content="<?php echo $description; ?>">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header class="header">
        <div class="container">
            <nav class="nav">
                <div class="logo">GRUPO APOENA</div>
                <ul class="nav-links">
                    <li><a href="<?php echo BASE_URL; ?>">Home</a></li>
                    <li><a href="#sobre">Sobre</a></li>
                    <li><a href="#solucoes">Soluções</a></li>
                    <li><a href="#contato">Contato</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="hero">
            <div class="container">
                <h1>Transformando o Futuro com <span class="highlight">Biotecnologia</span></h1>
                <p>O Grupo Apoena é o hub de inovação estratégica para biociência, agronegócio e cuidados pessoais.</p>
                <div class="cta-group">
                    <a href="#solucoes" class="btn btn-primary">Conheça nossas Unidades</a>
                </div>
            </div>
        </section>

        <section id="solucoes" class="units">
            <div class="container">
                <h2 class="section-title">Nossas Unidades de Negócio</h2>
                <div class="grid">
                    <?php foreach ($sites as $site): ?>
                    <div class="card card-<?php echo $site['color']; ?>">
                        <h3><?php echo $site['name']; ?></h3>
                        <p><?php echo $site['description']; ?></p>
                        <a href="<?php echo $site['url']; ?>" target="_blank" class="btn-link">Acessar Site &rarr;</a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    </main>

    <footer class="footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Grupo Apoena. Desenvolvido por Rodrigo Marchi Gonella.</p>
        </div>
    </footer>
</body>
</html>

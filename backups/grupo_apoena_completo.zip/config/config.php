<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'grupo_apoena');
define('DB_USER', 'root');
define('DB_PASS', '');

define('BASE_URL', 'http://localhost/grupo-apoena/public');
define('SITE_NAME', 'Grupo Apoena');

// Site specific domains/paths
define('DOMAINS', [
    'main' => 'apoena.com.br',
    'biotech' => 'biotech.apoena.com.br',
    'agro' => 'agro.apoena.com.br',
    'biocare' => 'biocare.apoena.com.br'
]);
